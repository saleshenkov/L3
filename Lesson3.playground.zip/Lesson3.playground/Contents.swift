//: A Cocoa based Playground to present user interface
import Foundation

enum Transmission {
    case auto, manual
}
enum Engine {
    case stopped, started
}
enum DoorState {
    case open, closed
}
enum TrunkState {
    case empty,full
}
struct TruckCar {
        var engine: Engine
        var carBrand: String
        var yearOfProduction: Int
        var multimediaCenter: Bool
        var transmission: Transmission
        var km: Double
        var doorState: DoorState
        var trunkstate: TrunkState
        
        mutating func stopEngine() {
            self.engine = .stopped
        }
        
}
struct SportCar {
        var engine: Engine
        var carBrand: String
        var yearOfProduction: Int
        var multimediaCenter: Bool
        var transmission: Transmission
        var km: Double
        var doorState: DoorState
        var trunkstate: TrunkState
        
        mutating func stopEngine() {
            self.engine = .stopped
        }
        
}


var car1 = TruckCar(engine: .started, carBrand: "Volvo", yearOfProduction: 2020, multimediaCenter: true, transmission: .auto, km: 10000, doorState: .closed, trunkstate: .empty)
let car2 = SportCar(engine: .stopped, carBrand: "Ford GT", yearOfProduction: 2018, multimediaCenter: true, transmission: .manual, km: 1000, doorState: .closed, trunkstate: .empty)


print(car1.transmission)
print(car1.carBrand)
print(car1.doorState)
print(car1.engine)
car1.stopEngine()
print(car1.engine, "\n")

print(car2.transmission)
print(car2.carBrand)
print(car2.doorState)

